This is a copy of the mqttws31 script from https://eclipse.org/paho/clients/js/ to add it on bower.
